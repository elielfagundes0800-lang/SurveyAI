package com.surveyai

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(32, 40, 32, 40)
            setBackgroundColor(0xFF101116.toInt())
        }
        val title = TextView(this).apply {
            text = "SurveyAI"
            textSize = 30f
            setTextColor(0xFFFFFFFF.toInt())
        }
        val info = TextView(this).apply {
            text = "Assistente de surveys\n\n1. Autoriza a sobreposição.\n2. Ativa o serviço de acessibilidade.\n3. Abre o survey e usa a bolha flutuante.\n\nA leitura de ecrã é processada no dispositivo nesta versão inicial."
            textSize = 16f
            setTextColor(0xFFB8BBC7.toInt())
            setPadding(0, 24, 0, 24)
        }
        val overlay = Button(this).apply {
            text = "Autorizar botão flutuante"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                } else startService(Intent(this@MainActivity, OverlayService::class.java))
            }
        }
        val accessibility = Button(this).apply {
            text = "Ativar acessibilidade"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        val start = Button(this).apply {
            text = "Iniciar SurveyAI"
            setOnClickListener {
                if (Settings.canDrawOverlays(this@MainActivity)) startService(Intent(this@MainActivity, OverlayService::class.java))
            }
        }
        root.addView(title); root.addView(info); root.addView(overlay); root.addView(accessibility); root.addView(start)
        setContentView(root)
    }
}
