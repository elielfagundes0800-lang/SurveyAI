# SurveyAI Android starter — build na nuvem

Este pacote inclui o código-fonte inicial e um workflow do GitHub Actions para tentar compilar um APK de teste na nuvem.

## Atenção
Este é um protótipo inicial, não uma aplicação completa. A IA online ainda não está ligada; o painel permite visualizar texto acessível e preencher o campo de texto focado depois de confirmação. Sites que não expõem texto à acessibilidade ainda precisam de captura consentida + OCR. Não usa a captura de ecrã nesta versão.

## Como gerar um APK usando apenas o telemóvel

1. Crie uma conta gratuita em https://github.com/signup e confirme o e-mail.
2. No navegador do telemóvel, entre em https://github.com e crie um repositório novo chamado `SurveyAI`. Escolha **Public** (para facilitar este teste) e marque **Add a README file**.
3. Extraia este ZIP no telemóvel usando a aplicação Ficheiros ou um gestor de arquivos.
4. Abra o repositório no GitHub, toque em **Add file** > **Upload files** e envie os ficheiros e pastas do projeto extraído para a raiz do repositório. É importante manter a estrutura de pastas, incluindo `.github/workflows/android.yml`. Se o navegador não permitir enviar pastas inteiras, use a vista "Site para computador" ou peça ajuda para fazer este único envio.
5. Aguarde o GitHub Actions iniciar o workflow após o envio. Abra o separador **Actions**, escolha **Build SurveyAI APK** e aguarde ficar verde.
6. Abra a execução concluída e descarregue o artefacto **SurveyAI-debug-apk**. Dentro estará `app-debug.apk`.
7. Abra o APK no telemóvel e autorize a instalação desta origem, se o Android pedir.

## Se o workflow não iniciar
No repositório, abra **Actions** e permita workflows se o GitHub pedir. Depois escolha **Build SurveyAI APK** e toque em **Run workflow**.

## O que esta versão faz e não faz
- Tem uma interface inicial escura e uma bolha flutuante.
- Tenta ler texto que a página disponibiliza através da árvore de acessibilidade do Android.
- Permite preencher o campo editável atualmente focado após toque explícito.
- Não envia respostas nem submete questionários automaticamente.
- Ainda não tem IA ligada, nem OCR via captura de ecrã, nem leitura garantida de todas as páginas.
- O APK gerado é um APK de depuração para teste, não uma versão final de distribuição.

Não coloque chaves privadas de API dentro do APK ou do repositório.
