package com.surveyai

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var bubble: android.view.View? = null
    private var panel: android.view.View? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return START_NOT_STICKY }
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        if (bubble == null) showBubble()
        return START_STICKY
    }

    private fun params(width: Int, height: Int) = WindowManager.LayoutParams(
        width, height, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
        PixelFormat.TRANSLUCENT
    ).apply { gravity = Gravity.TOP or Gravity.END; x = 20; y = 220 }

    private fun showBubble() {
        val b = Button(this).apply {
            text = "AI"
            textSize = 14f
            setTextColor(0xFFFFFFFF.toInt())
            setBackgroundColor(0xFF6655D9.toInt())
            setOnClickListener { showPanel() }
        }
        bubble = b
        wm.addView(b, params(64, 58))
    }

    private fun showPanel() {
        if (panel != null) return
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 20, 24, 20)
            setBackgroundColor(0xFF171922.toInt())
        }
        val heading = TextView(this).apply {
            text = "SurveyAI  •  Assistente"
            textSize = 18f
            setTextColor(0xFFFFFFFF.toInt())
        }
        val screenText = TextView(this).apply {
            text = SurveyAccessibilityService.latestVisibleText.ifBlank {
                "Ainda não foi possível ler texto desta página. Ativa a acessibilidade e volta ao survey."
            }
            textSize = 13f
            setTextColor(0xFFD1D3DC.toInt())
            setPadding(0, 14, 0, 14)
        }
        val answer = EditText(this).apply {
            hint = "Revê ou escreve a resposta sugerida"
            setTextColor(0xFFFFFFFF.toInt())
            setHintTextColor(0xFF9296A5.toInt())
            setSingleLine(false)
        }
        val note = TextView(this).apply {
            text = "A geração por IA será ligada a um servidor seguro numa próxima etapa. Confirma sempre que a resposta corresponde à tua experiência."
            textSize = 11f
            setTextColor(0xFF9296A5.toInt())
            setPadding(0, 8, 0, 8)
        }
        val fill = Button(this).apply {
            text = "Confirmar e preencher campo focado"
            setOnClickListener {
                val value = answer.text.toString()
                if (value.isNotBlank()) SurveyAccessibilityService.fillFocusedField(value)
                closePanel()
            }
        }
        val close = Button(this).apply { text = "Fechar"; setOnClickListener { closePanel() } }
        box.addView(heading); box.addView(screenText); box.addView(answer); box.addView(note); box.addView(fill); box.addView(close)
        panel = box
        val p = WindowManager.LayoutParams(
            (resources.displayMetrics.widthPixels * 0.88).toInt(),
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.CENTER }
        wm.addView(box, p)
    }

    private fun closePanel() {
        panel?.let { wm.removeView(it) }
        panel = null
    }

    override fun onDestroy() {
        bubble?.let { wm.removeView(it) }
        closePanel()
        bubble = null
        super.onDestroy()
    }
}
