package com.surveyai

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.os.Bundle

class SurveyAccessibilityService : AccessibilityService() {
    companion object {
        @Volatile var latestVisibleText: String = ""
        @Volatile private var instance: SurveyAccessibilityService? = null

        fun fillFocusedField(value: String) {
            val service = instance ?: return
            val root = service.rootInActiveWindow ?: return
            val target = findFocusedEditable(root) ?: return
            val args = Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, value) }
            target.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
        }

        private fun findFocusedEditable(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
            if (node.isFocused && node.isEditable) return node
            for (i in 0 until node.childCount) {
                val found = node.getChild(i)?.let { findFocusedEditable(it) }
                if (found != null) return found
            }
            return null
        }
    }

    override fun onServiceConnected() { instance = this }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val root = rootInActiveWindow ?: return
        val out = StringBuilder()
        collectText(root, out)
        latestVisibleText = out.toString().take(7000)
    }

    private fun collectText(node: AccessibilityNodeInfo, out: StringBuilder) {
        node.text?.toString()?.takeIf { it.isNotBlank() }?.let { out.append(it).append('\n') }
        node.contentDescription?.toString()?.takeIf { it.isNotBlank() }?.let { out.append(it).append('\n') }
        for (i in 0 until node.childCount) node.getChild(i)?.let { collectText(it, out) }
    }

    override fun onInterrupt() {}
    override fun onDestroy() { instance = null; super.onDestroy() }
}
